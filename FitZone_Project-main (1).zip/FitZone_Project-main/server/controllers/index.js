module.exports = {
  ...require('./authController'),
  ...require('./userController'),
  ...require('./memberController'),
  ...require('./trainerController'),
  ...require('./classController'),
  ...require('./subscriptionController'),
  ...require('./equipmentController'),
};
