module.exports = {
  authRoutes: require('./authRoutes'),
  userRoutes: require('./userRoutes'),
  memberRoutes: require('./memberRoutes'),
  trainerRoutes: require('./trainerRoutes'),
  classRoutes: require('./classRoutes'),
  subscriptionRoutes: require('./subscriptionRoutes'),
  equipmentRoutes: require('./equipmentRoutes'),
  chatRoutes: require('./chatRoutes'),
};
